export const CHATWOOT_API_PLUGIN_OPTIONS = Symbol('CHATWOOT_API_PLUGIN_OPTIONS');
export const loggerCtx = 'ChatwootApiPlugin';
